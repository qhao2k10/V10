package com.example.vipgamebooster

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import com.example.vipgamebooster.core.UltimateGameEngineCore

class LauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        UltimateGameEngineCore.initialize(applicationContext)
        UltimateGameEngineCore.engageGodMode(resolveTargetGamePackage())

        finishAndRemoveTask()
    }

    private fun resolveTargetGamePackage(): String {
        intent?.getStringExtra("target_package")?.let { target ->
            if (target.isNotBlank()) return target
        }

        return try {
            val appInfo = packageManager.getApplicationInfo(
                packageName,
                PackageManager.GET_META_DATA
            )
            appInfo.metaData?.getString("default_target_game_package")
                ?.takeIf { it.isNotBlank() }
                ?: packageName
        } catch (_: Exception) {
            packageName
        }
    }
}
