package com.example.vipgamebooster

import android.app.Application
import com.example.vipgamebooster.core.UltimateGameEngineCore

class LqhOptimizerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        UltimateGameEngineCore.initialize(this)
    }
}
