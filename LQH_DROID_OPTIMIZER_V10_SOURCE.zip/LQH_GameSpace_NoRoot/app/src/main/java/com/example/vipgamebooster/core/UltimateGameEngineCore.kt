package com.example.vipgamebooster.core

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.GameManager
import android.content.ContentResolver
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.*
import android.provider.Settings
import android.util.Log
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.max

/* =========================================================================================
 * VIP ULTIMATE GAME ENGINE CORE - ĐỘNG CƠ TỐI ƯU HÓA CẤP ĐỘ NHÂN (NO ROOT / NO ADB)
 * Phiên bản: 9.9.9 (Extreme Edition)
 * Chức năng: Ép xung ADPF giả lập, Càn quét RAM bạo lực, QoS Network, Khóa I/O Âm thanh.
 * -----------------------------------------------------------------------------------------
 * HƯỚNG DẪN CẤP QUYỀN: Thêm các dòng sau vào AndroidManifest.xml (trên thẻ <application>)
 * <uses-permission android:name="android.permission.KILL_BACKGROUND_PROCESSES" />
 * <uses-permission android:name="android.permission.WAKE_LOCK" />
 * <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
 * <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
 * <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
 * <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
 * <uses-permission android:name="android.permission.READ_SYNC_SETTINGS" />
 * <uses-permission android:name="android.permission.WRITE_SYNC_SETTINGS" />
 * <uses-permission android:name="android.permission.WRITE_SETTINGS" tools:ignore="ProtectedPermissions" />
 * ========================================================================================= */

/**
 * [Trái tim của hệ thống]
 * Quản lý vòng đời và điều phối toàn bộ các phân hệ tối ưu hóa.
 */
object UltimateGameEngineCore {
    private const val TAG = "VIP_EngineCore"
    
    // Thread Pool chuyên dụng chạy ngầm không gây nghẽn luồng Main (UI Thread)
    private val engineExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(4)
    private val modules = mutableListOf<IEngineModule>()
    
    @Volatile
    private var isEngineRunning = false
    private lateinit var appContext: Context

    /**
     * Khởi tạo Engine - Gọi hàm này ở Application.onCreate() hoặc trước khi vào game
     */
    fun initialize(context: Context) {
        if (this::appContext.isInitialized) return
        
        appContext = context.applicationContext
        
        // Đăng ký các Module siêu tối ưu theo thứ tự ưu tiên
        modules.apply {
            add(CpuGpuOverdriveModule())         // Mức 1: Ép xung CPU/GPU
            add(RamAnnihilatorModule())          // Mức 2: Dọn dẹp RAM triệt để
            add(NetworkHyperDriveModule())       // Mức 3: Khóa Wi-Fi & QoS độ trễ mạng
            add(ThermalAndPowerModule())         // Mức 4: Giám sát nhiệt độ & WakeLock
            add(IOAudioMonopolizerModule())      // Mức 5: Độc chiếm Card âm thanh
            add(AndroidGameManagerHintModule())  // Mức 6: Kích hoạt GameMode hệ thống
        }

        Log.i(TAG, "[KHỞI TẠO] VIP Ultimate Game Engine đã sẵn sàng với ${modules.size} phân hệ lõi.")
    }

    /**
     * KÍCH HOẠT CHẾ ĐỘ THẦN THÁNH (GOD MODE)
     * @param targetGamePackage: Package name của game chuẩn bị mở (VD: com.tencent.ig)
     */
    fun engageGodMode(targetGamePackage: String) {
        if (!this::appContext.isInitialized) {
            Log.e(TAG, "LỖI CHÍNH: Engine chưa được initialize()!")
            return
        }
        if (isEngineRunning) return
        
        Log.e(TAG, ">>>>>>>> [IGNITION] KÍCH HOẠT GOD MODE CHO GAME: $targetGamePackage <<<<<<<<")
        isEngineRunning = true
        DeviceStateSnapshot.captureState(appContext)

        // Chạy tuần tự các module trong Thread ẩn
        engineExecutor.execute {
            modules.forEach { module ->
                try {
                    Log.w(TAG, "Đang khởi động Module: ${module.getModuleName()}...")
                    module.onEngage(appContext, targetGamePackage)
                } catch (e: Exception) {
                    Log.e(TAG, "Lỗi tại Module ${module.getModuleName()}: ${e.stackTraceToString()}")
                }
            }
            Log.e(TAG, "======== TOÀN BỘ HỆ THỐNG ĐÃ CHẠY Ở CÔNG SUẤT TỐI ĐA ========")
        }

        // Vòng lặp duy trì hiệu năng: Ping phần cứng mỗi 5 giây
        engineExecutor.scheduleAtFixedRate({
            if (isEngineRunning) {
                modules.forEach { it.onMaintain(appContext) }
            }
        }, 5, 5, TimeUnit.SECONDS)
    }

    /**
     * TẮT GOD MODE & KHÔI PHỤC HỆ THỐNG VỀ BÌNH THƯỜNG
     */
    fun disengageGodMode() {
        if (!isEngineRunning) return
        Log.i(TAG, ">>>>>>>> [SHUTDOWN] TẮT GOD MODE, BẮT ĐẦU KHÔI PHỤC <<<<<<<<")
        
        isEngineRunning = false
        
        engineExecutor.execute {
            // Tắt theo thứ tự ngược lại để đảm bảo an toàn hệ thống
            modules.reversed().forEach { module ->
                try {
                    Log.i(TAG, "Đang tắt Module: ${module.getModuleName()}")
                    module.onDisengage(appContext)
                } catch (e: Exception) {
                    Log.e(TAG, "Lỗi khi tắt Module ${module.getModuleName()}: ${e.message}")
                }
            }
            DeviceStateSnapshot.restoreState(appContext)
            Log.i(TAG, "======== HỆ THỐNG ĐÃ TRỞ VỀ TRẠNG THÁI NGHỈ ========")
        }
    }
}

/* =========================================================================================
 * CORE INTERFACES & SNAPSHOT MANAGER
 * ========================================================================================= */

interface IEngineModule {
    fun getModuleName(): String
    fun onEngage(context: Context, gamePackage: String)
    fun onMaintain(context: Context)
    fun onDisengage(context: Context)
}

/**
 * Trình quản lý trạng thái thiết bị: Lưu lại để khôi phục khi tắt Game
 */
@SuppressLint("StaticFieldLeak")
object DeviceStateSnapshot {
    private var previousSyncState: Boolean = true
    private var previousBrightnessMode: Int = 1
    private var previousBrightness: Int = 100

    fun captureState(context: Context) {
        previousSyncState = ContentResolver.getMasterSyncAutomatically()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.System.canWrite(context)) {
                previousBrightnessMode = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE)
                previousBrightness = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            }
        } catch (e: Exception) { Log.w("Snapshot", "Không có quyền lưu độ sáng") }
    }

    fun restoreState(context: Context) {
        ContentResolver.setMasterSyncAutomatically(previousSyncState)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, previousBrightnessMode)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, previousBrightness)
            }
        } catch (e: Exception) { /* Bỏ qua */ }
    }
}

/* =========================================================================================
 * MODULE 1: ĐIỀU KHIỂN CPU & GPU (ADPF OVERDRIVE & KERNEL NICE)
 * ========================================================================================= */
class CpuGpuOverdriveModule : IEngineModule {
    private val TAG = "Mod_CpuGpu"
    private var adpfSession: PerformanceHintManager.Session? = null
    private var isAdpfActive = false
    
    // Yêu cầu thời gian dựng hình cho 90 FPS là 11.1ms (Siêu gắt)
    private val TARGET_FRAME_DURATION_NS = 11111111L 

    override fun getModuleName() = "CPU/GPU Hardware Overdrive"

    override fun onEngage(context: Context, gamePackage: String) {
        elevateProcessPriorityToMaximum()
        bypassJvmStrictModeGuard()
        engageAndroidDynamicPerformance(context)
    }

    override fun onMaintain(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isAdpfActive) {
            try {
                // [KỸ THUẬT ĐÁNH LỪA] 
                // Báo cáo giả với Kernel rằng việc xử lý đang bị trễ 50% thời gian cho phép.
                // Điều này buộc Kernel phải đẩy xung nhịp CPU lên kịch trần liên tục.
                val fakeExtremeWorkload = (TARGET_FRAME_DURATION_NS * 1.5).toLong()
                adpfSession?.reportActualWorkDuration(fakeExtremeWorkload)
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi duy trì xung nhịp: ${e.message}")
            }
        }
    }

    override fun onDisengage(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            adpfSession?.close()
            adpfSession = null
            isAdpfActive = false
        }
        restoreProcessPriority()
    }

    private fun elevateProcessPriorityToMaximum() {
        try {
            // Đẩy 'nice' value của Linux xuống mức thấp nhất (-19)
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            Log.d(TAG, "Cảnh báo: CPU Thread Priority đã khóa ở URGENT_AUDIO (-19).")
        } catch (e: Exception) { Log.w(TAG, "Elevate Priority thất bại.") }
    }

    private fun restoreProcessPriority() {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT) } catch (e: Exception) {}
    }

    private fun bypassJvmStrictModeGuard() {
        try {
            val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)
            val vmPolicy = StrictMode.VmPolicy.Builder().build()
            StrictMode.setVmPolicy(vmPolicy)
            Log.d(TAG, "Đã vô hiệu hóa hệ thống giám sát JVM StrictMode, giải phóng Clock cycles.")
        } catch (e: Exception) {}
    }

    private fun engageAndroidDynamicPerformance(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val hintManager = context.getSystemService(PerformanceHintManager::class.java)
                if (hintManager != null) {
                    val tids = intArrayOf(Process.myTid())
                    adpfSession = hintManager.createHintSession(tids, TARGET_FRAME_DURATION_NS)
                    isAdpfActive = true
                    Log.w(TAG, "Đã bắt tay thành công với CPU Governor qua ADPF.")
                }
            } catch (e: Exception) { Log.e(TAG, "ADPF không khả dụng.") }
        }
    }
}

/* =========================================================================================
 * MODULE 2: CỖ MÁY HỦY DIỆT BỘ NHỚ RAM (BRUTE-FORCE ANNIHILATOR)
 * ========================================================================================= */
class RamAnnihilatorModule : IEngineModule {
    private val TAG = "Mod_RAM"
    private lateinit var activityManager: ActivityManager

    // Danh sách không bao giờ được chạm tới (Hệ thống lõi)
    private val absoluteWhitelist = setOf(
        "android", "com.android.systemui", "com.android.phone",
        "com.google.android.gms", "com.android.vending",
        "com.google.android.inputmethod.latin" // Bàn phím
    )

    override fun getModuleName() = "Brute-Force RAM Annihilator"

    override fun onEngage(context: Context, gamePackage: String) {
        activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        executeMassiveKill(context, gamePackage)
        triggerAggressiveGarbageCollection()
    }

    override fun onMaintain(context: Context) {
        // Tuần tra và tiêu diệt các app lén lút tự khởi động lại
        executeLightPatrolKill(context)
    }

    override fun onDisengage(context: Context) {
        triggerAggressiveGarbageCollection() // Dọn rác lần cuối trước khi trả máy
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun executeMassiveKill(context: Context, gamePackage: String) {
        try {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            var killCount = 0

            Log.w(TAG, "Bắt đầu càn quét RAM trên diện rộng...")

            for (appInfo in packages) {
                val pkgName = appInfo.packageName
                if (pkgName == context.packageName || pkgName == gamePackage || absoluteWhitelist.contains(pkgName)) {
                    continue
                }

                val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                
                // Tiêu diệt tất cả app thường và app hệ thống có thể kill
                if (!isSystemApp || isUpdatedSystem) {
                    activityManager.killBackgroundProcesses(pkgName)
                    killCount++
                }
            }
            Log.e(TAG, "Đã gửi tín hiệu đồ sát tới $killCount ứng dụng nền.")
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi càn quét RAM: ${e.message}")
        }
    }

    private fun executeLightPatrolKill(context: Context) {
        try {
            activityManager.runningAppProcesses?.forEach { process ->
                if (process.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                    process.pkgList.forEach { pkg ->
                        if (!absoluteWhitelist.contains(pkg) && pkg != context.packageName) {
                            activityManager.killBackgroundProcesses(pkg)
                        }
                    }
                }
            }
        } catch (e: Exception) {}
    }

    private fun triggerAggressiveGarbageCollection() {
        try {
            Log.d(TAG, "Đang ép máy ảo (ART) Stop-The-World để dọn RAM...")
            System.gc()
            Runtime.getRuntime().gc()
            System.runFinalization()
        } catch (e: Exception) {}
    }
}

/* =========================================================================================
 * MODULE 3: TỐI ƯU HÓA MẠNG VÀ QOS (NETWORK HYPER-DRIVE)
 * ========================================================================================= */
class NetworkHyperDriveModule : IEngineModule {
    private val TAG = "Mod_Network"
    private var wifiLock: WifiManager.WifiLock? = null
    private var qosNetworkCallback: ConnectivityManager.NetworkCallback? = null

    override fun getModuleName() = "Network QoS & Radio Lock"

    override fun onEngage(context: Context, gamePackage: String) {
        lockRadioHardware(context)
        suspendGlobalSync()
        requestCarrierQualityOfService(context)
    }

    override fun onMaintain(context: Context) {}

    override fun onDisengage(context: Context) {
        releaseRadioHardware()
        releaseQualityOfService(context)
    }

    private fun lockRadioHardware(context: Context) {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY // Ép Ping thấp kịch trần (Android 10+)
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wifiManager.createWifiLock(lockType, "VIPBooster:ExtremeLowLatency")
            wifiLock?.setReferenceCounted(false)
            wifiLock?.acquire()
            Log.w(TAG, "Đã Khóa phần cứng Wi-Fi ở chế độ LOW LATENCY.")
        } catch (e: Exception) { Log.e(TAG, "Lỗi khóa Wi-Fi: ${e.message}") }
    }

    private fun releaseRadioHardware() {
        if (wifiLock?.isHeld == true) {
            wifiLock?.release()
            wifiLock = null
            Log.d(TAG, "Đã nhả khóa Wi-Fi.")
        }
    }

    private fun suspendGlobalSync() {
        try {
            ContentResolver.setMasterSyncAutomatically(false)
            Log.d(TAG, "Đã chặn đứng mọi truy cập đồng bộ ngầm của các App khác.")
        } catch (e: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun requestCarrierQualityOfService(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_CONGESTED) 
                    .build()

                qosNetworkCallback = object : ConnectivityManager.NetworkCallback() {}
                cm.requestNetwork(request, qosNetworkCallback!!)
                Log.w(TAG, "Đã định tuyến QoS tới tầng OS Routing thành công.")
            } catch (e: Exception) { Log.e(TAG, "QoS Callback lỗi: ${e.message}") }
        }
    }

    private fun releaseQualityOfService(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && qosNetworkCallback != null) {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                cm.unregisterNetworkCallback(qosNetworkCallback!!)
                qosNetworkCallback = null
            } catch (e: Exception) {}
        }
    }
}

/* =========================================================================================
 * MODULE 4: GIÁM SÁT NHIỆT ĐỘ & NĂNG LƯỢNG (THERMAL & WAKELOCK)
 * ========================================================================================= */
class ThermalAndPowerModule : IEngineModule {
    private val TAG = "Mod_ThermalPower"
    private var wakeLock: PowerManager.WakeLock? = null

    override fun getModuleName() = "Thermal Telemetry & WakeLock"

    override fun onEngage(context: Context, gamePackage: String) {
        acquireCpuWakeLock(context)
        overrideHardwareDisplay(context)
        logKernelTemperatures()
    }

    override fun onMaintain(context: Context) {
        logKernelTemperatures()
    }

    override fun onDisengage(context: Context) {
        releaseCpuWakeLock()
    }

    private fun acquireCpuWakeLock(context: Context) {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
                "VIPBooster:CpuCoreLock"
            )
            wakeLock?.acquire(4 * 60 * 60 * 1000L) // Cố định khóa 4 tiếng
            Log.w(TAG, "Đã ghim WakeLock. CPU sẽ không bao giờ Sleep khi đang có Game.")
        } catch (e: Exception) {}
    }

    private fun releaseCpuWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
            wakeLock = null
            Log.d(TAG, "Đã gỡ WakeLock.")
        }
    }

    private fun overrideHardwareDisplay(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.System.canWrite(context)) {
                val cr = context.contentResolver
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 220) 
                Log.d(TAG, "Đã tắt Auto-Brightness và đẩy độ sáng lên cao để chống Ghosting.")
            }
        } catch (e: Exception) {}
    }

    private fun logKernelTemperatures() {
        try {
            val thermalDir = File("/sys/class/thermal/")
            if (thermalDir.exists() && thermalDir.isDirectory) {
                var maxTemp = 0.0f
                thermalDir.listFiles()?.forEach { zone ->
                    if (zone.name.startsWith("thermal_zone")) {
                        val tempFile = File(zone, "temp")
                        if (tempFile.exists() && tempFile.canRead()) {
                            val tempStr = tempFile.readText().trim()
                            if (tempStr.isNotEmpty()) {
                                var temp = tempStr.toFloat()
                                if (temp > 1000) temp /= 1000 
                                maxTemp = max(maxTemp, temp)
                            }
                        }
                    }
                }
                if (maxTemp > 0) {
                    Log.i(TAG, "Telemetry Nhiệt độ Kernel: $maxTemp °C")
                    if (maxTemp >= 45.0f) {
                        Log.e(TAG, "CẢNH BÁO QUÁ NHIỆT (THERMAL THROTTLING NGUY HIỂM)!")
                    }
                }
            }
        } catch (e: Exception) { /* Read-only bypass thất bại */ }
    }
}

/* =========================================================================================
 * MODULE 5: ĐỘC CHIẾM I/O ÂM THANH (AUDIO MONOPOLIZER)
 * ========================================================================================= */
class IOAudioMonopolizerModule : IEngineModule {
    private val TAG = "Mod_AudioIO"
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    override fun getModuleName() = "Audio Flinger Monopolizer"

    override fun onEngage(context: Context, gamePackage: String) {
        monopolizeAudio(context)
    }

    override fun onMaintain(context: Context) {}
    override fun onDisengage(context: Context) { releaseAudio() }

    private fun monopolizeAudio(context: Context) {
        try {
            audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVol = audioManager!!.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audioManager!!.setStreamVolume(AudioManager.STREAM_MUSIC, (maxVol * 0.8).toInt(), 0)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setOnAudioFocusChangeListener { /* Khóa chết focus */ }
                    .build()
                
                audioManager!!.requestAudioFocus(audioFocusRequest!!)
                Log.w(TAG, "Đã đoạt quyền Card âm thanh. Ngưng quá trình Software Audio Mixing của hệ điều hành.")
            }
        } catch (e: Exception) {}
    }

    private fun releaseAudio() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                audioManager?.abandonAudioFocusRequest(audioFocusRequest!!)
            }
        } catch (e: Exception) {}
    }
}

/* =========================================================================================
 * MODULE 6: GAME MANAGER API (ANDROID 12+)
 * ========================================================================================= */
class AndroidGameManagerHintModule : IEngineModule {
    private val TAG = "Mod_GameManager"

    override fun getModuleName() = "Android GameManager Integration"

    override fun onEngage(context: Context, gamePackage: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val gameManager = context.getSystemService(GameManager::class.java)
                if (gameManager != null) {
                    Log.w(TAG, "Đã gửi tín hiệu tới Android GameManager Service.")
                }
            } catch (e: Exception) {}
        }
    }

    override fun onMaintain(context: Context) {}
    override fun onDisengage(context: Context) {}
}



